# SonderMind Billing Tracker

## Q4 2023 Overview

| Metric | October | November | December | Q4 Total |
|--------|---------|----------|----------|----------|
| Total Sessions | 12,574 | 13,201 | 11,895 | 37,670 |
| Revenue | $1,068,790 | $1,122,085 | $1,010,575 | $3,201,450 |
| Avg. Revenue per Session | $85.00 | $85.00 | $85.00 | $85.00 |
| Insurance Claims Processed | 10,059 | 10,561 | 9,516 | 30,136 |
| Out-of-Pocket Payments | 2,515 | 2,640 | 2,379 | 7,534 |

## Session Type Breakdown

| Session Type | Count | % of Total | Revenue |
|--------------|-------|------------|---------|
| 30-minute | 5,651 | 15% | $395,570 |
| 45-minute | 15,068 | 40% | $1,506,800 |
| 60-minute | 16,951 | 45% | $1,299,080 |

## Insurance Claims Status

- Submitted: 30,136
- Approved: 28,629 (95%)
- Pending: 905 (3%)
- Denied: 602 (2%)

## Top 5 Insurance Providers

1. Blue Cross Blue Shield: 8,438 claims
2. UnitedHealthcare: 6,027 claims
3. Aetna: 4,520 claims
4. Cigna: 3,616 claims
5. Humana: 2,411 claims

## Accounts Receivable Aging

| Days Outstanding | Amount | % of Total |
|------------------|--------|------------|
| 0-30 days | $2,561,160 | 80% |
| 31-60 days | $480,217 | 15% |
| 61-90 days | $96,043 | 3% |
| 90+ days | $64,029 | 2% |

## Provider Payout Summary

- Total Providers: 1,245
- Average Payout per Provider: $2,072
- Top Earner: Dr. Sarah Johnson (NH) - $12,350
- Lowest Earner: Dr. Michael Chen (CA) - $425 (part-time)

## Billing Cycle Metrics

- Average Days to Payment: 18
- Claims Submission Rate: 98%
- Clean Claim Rate: 94%
- Denial Rate: 2%

## Action Items

- [ ] Follow up on 90+ day outstanding claims
- [ ] Analyze reason for increased denials in California region
- [ ] Schedule training for new billing codes effective Jan 1, 2024
- [ ] Review pricing strategy for 30-minute sessions

## Notes

- New Hampshire providers showing higher than average initial intake fees
- Missouri region experiencing 5% increase in out-of-pocket payments
- Implemented new automated claims submission process in December, monitoring for efficiency gains