# SonderMind New Hire Onboarding Tracker

## Employee Information
| Field | Details |
|-------|---------|
| Name: | |
| Start Date: | |
| Position: | |
| Department: | |
| Manager: | |

## Pre-Boarding Checklist
- [ ] Offer letter signed and returned
- [ ] Background check completed
- [ ] I-9 documentation submitted
- [ ] Equipment ordered (laptop, headset, etc.)
- [ ] SonderMind email account created
- [ ] Added to relevant Slack channels
- [ ] Access granted to HIPAA-compliant systems

## Week 1: Welcome to SonderMind

### Day 1
- [ ] Welcome meeting with HR (9:00 AM)
- [ ] Company overview presentation (10:30 AM)
- [ ] IT setup and systems introduction (1:00 PM)
- [ ] Review SonderMind's mission and values
- [ ] Complete HIPAA training

### Day 2-3
- [ ] Shadow therapy matching process
- [ ] Introduction to SonderMind's proprietary matching algorithm
- [ ] Review client intake form and therapist profile structure
- [ ] Familiarize with telehealth platform features

### Day 4-5
- [ ] Department-specific onboarding sessions
- [ ] Meet with direct manager for role expectations
- [ ] Review Q2 2023 OKRs and team goals
- [ ] Set up 1:1s with key team members

## Week 2: Deep Dive into SonderMind Operations

- [ ] Complete compliance training modules
- [ ] Review SonderMind's insurance partnerships and billing processes
- [ ] Understand therapist credentialing and onboarding workflow
- [ ] Deep dive into client acquisition funnel and retention strategies
- [ ] Familiarize with SonderMind's data analytics and reporting tools

## Week 3-4: Role-Specific Training and Projects

- [ ] Complete role-specific training modules in SonderMind LMS
- [ ] Shadowing sessions with experienced team members
- [ ] Assign first project or task (discuss with manager)
- [ ] Set up recurring team meetings and stand-ups
- [ ] Review SonderMind's product roadmap and upcoming features

## 30-Day Check-In

- [ ] Schedule 30-day review with manager
- [ ] Complete self-assessment form
- [ ] Discuss initial impressions, challenges, and opportunities
- [ ] Set 60-day goals and expectations

## Key Performance Indicators (First 90 Days)

| Metric | Target |
|--------|--------|
| Client-Therapist Match Rate | >85% |
| Average Time to First Appointment | <7 days |
| Client Satisfaction Score | >4.5/5 |
| Therapist Retention Rate | >90% |
| Insurance Claim Acceptance Rate | >98% |

## Important Links and Resources

- SonderMind Employee Handbook: [internal link]
- Therapist Portal Guide: [internal link]
- Client Journey Map: [internal link]
- Quarterly All-Hands Meeting Schedule: [internal link]
- SonderMind Style Guide and Brand Assets: [internal link]

## Feedback on Onboarding Process

We value your input! Please complete our onboarding feedback survey at the end of your first month: [survey link]

---

*Remember, your success is our success. If you need any additional support during your onboarding journey, please reach out to your manager or HR representative.*